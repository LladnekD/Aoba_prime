module.exports = require('./aoba').default
